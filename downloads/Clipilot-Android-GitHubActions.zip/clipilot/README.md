# Clipilot AI — Android nativo

Aplicativo Kotlin + Jetpack Compose que recebe um comando em português, pede ao Gemini para gerar um plano JSON e executa operações locais com AndroidX Media3 Transformer.

## Recursos implementados
- Seleção de vídeo pelo seletor nativo do Android (sem permissão ampla de armazenamento).
- Leitura da duração do vídeo.
- Campo de comando em português.
- Interpretação de comandos via Gemini API.
- Plano de edição revisável antes de executar.
- Recorte do início/fim, remoção do áudio e filtro preto e branco.
- Exportação MP4 local com H.264/AAC.

## Limites atuais
Esta é uma primeira versão funcional, não um clone completo do CapCut. O modelo não recebe o vídeo; recebe apenas o texto do comando e a duração. Por isso, não consegue detectar automaticamente cenas, pessoas, batidas musicais ou pausas. A versão atual não implementa legendas, trilhas adicionais, transições, zooms dinâmicos, geração de música ou remoção de objetos.

## Requisitos
- Android Studio recente ou ambiente Gradle Android compatível.
- JDK 17.
- Android SDK 36 instalado.
- Internet para chamar a API Gemini.
- Chave da API Gemini criada em https://aistudio.google.com/apikey.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `Clipilot` no Android Studio.
3. Aguarde o Gradle sincronizar e instalar as dependências.
4. Configure a chave Gemini no ícone de configurações do app.
5. Execute em um dispositivo Android 6.0+.

Para gerar APK debug, na raiz do projeto execute:

```bash
gradle assembleDebug
```

O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Privacidade e chave da API
A chave é salva nas preferências privadas do app, sem criptografia adicional. Não distribua APKs com tua chave já gravada. Para um produto público, mova as chamadas de IA para um backend próprio ou implemente armazenamento protegido e limites de uso. O arquivo de vídeo é processado localmente e não é enviado ao Gemini nesta versão.

## Formato do plano de edição
```json
{
  "summary": "Cortar o início e converter para preto e branco",
  "start_ms": 5000,
  "end_ms": null,
  "mute_audio": false,
  "grayscale": true
}
```
